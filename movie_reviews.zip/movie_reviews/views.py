from django.http import HttpResponse
from django.shortcuts import render, get_object_or_404, redirect
from django.core.paginator import Paginator
from .models import Review
from .forms import ReviewForm

def front_page(request):
    return render(request, "review_index.html")
    # return render(request, "review_index_css.html")


def add_review(request):
    success = False
    added_review = None
    if request.method == "POST":
        form = ReviewForm(request.POST)
        if form.is_valid():
            new_review = form.save()
            success = True
            added_review = new_review
            return render(
                request,
                "add_review_css.html", # "add_review_css.html",
                {"form": form,
                 "added_review": added_review,
                 "success": success},
            )
    else:
        form = ReviewForm()
    return render(
        request,
        "add_review_css.html", # "add_review_css.html",
        {"form": form,
         "added_review": added_review,
         "success": success},
    )


def search_review(request):
    page_number = request.GET.get("page", 1)
    movie = request.GET.get("movie", "").strip()
    genre = request.GET.get("genre", "").strip()
    score = request.GET.get("score", "").strip()
    user = request.GET.get("user", "").strip()
    month = request.GET.get("month", "").strip()
    day = request.GET.get("day", "").strip()
    year = request.GET.get("year", "").strip()

    if request.method == "POST":
        movie = request.POST.get("movie", "").strip()
        genre = request.POST.get("genre", "").strip()
        score = request.POST.get("score", "").strip()
        user = request.POST.get("user", "").strip()
        month = request.POST.get("month", "").strip()
        day = request.POST.get("day", "").strip()
        year = request.POST.get("year", "").strip()
        # Reset to first page on new search
        page_number = 1

    if movie or genre or score or user or month or day or year:
        reviews = Review.objects.filter(
            movie__icontains=movie, genre__icontains=genre, score__icontains=score, user__icontains=user, month__icontains=month, day__icontains=day, year__icontains=year
        ).order_by("id")  # Order by name to ensure consistency
    else:
        reviews = Review.objects.all().order_by("id")  # Order the results

    paginator = Paginator(reviews, 10)
    page_obj = paginator.get_page(page_number)

    return render(
        request,
        "search_review_css.html",
        # "search_review.html",
        {"reviews": page_obj,
         "movie_query": movie,
         "genre_query": genre,
         "score_query": score,
         "user_query": user,
         "month_query": month,
         "day_query": day,
         "year_query": year},
    )

def edit_review(request, review_id, page_number):
    pn = request.GET.get("page", page_number)
    print(f"[DBG] edit_review {review_id}, {page_number}, {pn} <<<")
    success = False

    if request.method == "POST":
        review = Review.objects.get(id=review_id)
        movie = request.POST.get("movie")
        genre = request.POST.get("genre")
        score = request.POST.get("score")
        user = request.POST.get("user")
        month = request.POST.get("month")
        day = request.POST.get("day")
        year = request.POST.get("year")
        if review.movie != movie or review.genre != genre or review.score != score or review.user != user or review.month != month or review.day != day or review.year != year:
            review.movie = movie
            review.genre = genre
            review.score = score
            review.user = user
            review.month = month
            review.day = day
            review.year = year
            review.save()
            success = True

    review_list = Review.objects.all()
    paginator = Paginator(review_list, 10)
    page_number = request.POST.get(
        "page", request.GET.get("page", page_number)
    )
    page_obj = paginator.get_page(page_number)
    return render(
        request,
        # "edit_review.html",
        "edit_review_css.html",
        {
            "reviews": page_obj,
            "success": success,
            "updated_review_id": review_id,
        },
    )


def delete_review(request, review_id, page_number):
    print("[DBG] delete_review called for ID:", review_id)
    if request.method == "POST":
        review = get_object_or_404(Review, id=review_id)
        review.delete()
        # Redirect to the same page number after delete
        return redirect("edit_review", review_id=review_id, page_number=page_number)
