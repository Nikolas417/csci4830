from django import forms
from .models import Review

class ReviewForm(forms.ModelForm):
    class Meta:
        model = Review
        fields = ['id', 'movie', 'genre', 'score', 'user', 'day', 'month', 'year']
        # Apply CSS styles
        widgets = {
            'movie': forms.TextInput(attrs={
                'class': 'form-control', 
                'placeholder': 'Enter movie title',
            }),
            'genre': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter genre of movie',
            }),
            'score': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter movie rating (1-10 scale)',
            }),
            'user': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter a username to refer to yourself with',
            }),
            'day': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter date of viewing',
            }),
            'month': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter month of viewing',
            }),
            'year': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter year of viewing',
            }),
        }