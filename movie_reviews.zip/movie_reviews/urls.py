from django.urls import path
from .views import front_page
from .views import add_review
from .views import search_review
from .views import edit_review
from .views import delete_review

urlpatterns = [
    path("", front_page, name="front_page"),
    path("add/", add_review, name="add_review"),
    path("search/", search_review, name="search_review"),
    path(
        "edit_review/<int:review_id>/<int:page_number>/",
        edit_review,
        name="edit_review",
    ),
    path(
        "delete_review/<int:review_id>/<int:page_number>/",
        delete_review,
        name="delete_review",
    ),
]
