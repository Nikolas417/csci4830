from django.db import models

class Review(models.Model):
    id = models.AutoField(primary_key=True)
    movie = models.CharField(max_length=100)
    genre = models.CharField(max_length=25)
    score = models.IntegerField()
    user = models.CharField(max_length=25)
    month = models.IntegerField(max_length=2)
    day = models.IntegerField(max_length=2)
    year = models.IntegerField(max_length=4)

    def __str__(self):
        return self.user